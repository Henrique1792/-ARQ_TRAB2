//arquivos nossos
#include "booktag.h"
#include "screen.h"

/*
   Trabalho de Organizacao de Arquivos - Trabalho 2

   Integrantes:

   Marcos Vinicius Barros L. Andrade Junqueira     numero USP: 8922393
   Rita Raad                                       numero USP: 8061452
   Henrique Fernandes de Matos Freitas             numero USP: 8937225
   Gustavo Santiago                                numero USP: 8937416

   Descricao do arquivo main.c: funcao inicia o programa, simplesmente chama a funcao start_screen() (implementada no arquivo screen.c)
   e carrega o programa/interface de texto.
 */

int main(int argc, char *argv[]) {
    start_screen();
    return 0;
}
